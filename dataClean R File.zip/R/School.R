library(tidyverse)
library(dplyr)
library(stringi)
library(scales)
library(data.table)
setwd("C:\\Users\\rg\\Desktop\\Data_Science_Assignment")


# Read the CSV file and assign the year
SchoolData_2021_2022 <- fread("Datasets\\SchoolData_2021-2022\\2021-2022\\england_ks4final.csv", fill = TRUE) %>%
  mutate(Year = 2021)

# Select relevant columns, remove missing values, and keep distinct records
SchoolData_2021_2022 <- SchoolData_2021_2022%>%
  select( Year,PCODE,SCHNAME, ATT8SCR) %>% 
  na.omit() %>% 
  distinct()

# Read the CSV file and assign the year
SchoolData_2022_2023 <- fread("Datasets\\SchoolData_2021-2022\\2021-2022\\england_ks4final.csv", fill = TRUE) %>%
  mutate(Year = 2022)

# Select relevant columns, remove missing values, and keep distinct records
SchoolData_2022_2023 <- SchoolData_2022_2023 %>%
  select(Year,PCODE,SCHNAME, ATT8SCR) %>%
  drop_na() %>%
  distinct()

Combined_School = rbind(SchoolData_2021_2022,SchoolData_2022_2023)

pattern = ' .*$'

Cleaned_SchoolData = Combined_School %>% 
  mutate(ID = row_number()) %>% 
  mutate(S_Postcode=gsub(pattern,"",PCODE)) %>%
  filter (ATT8SCR != "NE" & ATT8SCR != "SUPP") %>% 
  filter(ATT8SCR !=""& S_Postcode!=""& PCODE!="") %>% 
  select( ID,Year,PCODE,S_Postcode,SCHNAME, ATT8SCR,) %>% 
  na.omit() %>% 
  distinct()
View(Cleaned_SchoolData)


colnames(Cleaned_SchoolData) = c("ID", "Year", "PostCode", "S_Postcode", "SchoolName", "Attainment8Score")

write.csv(Cleaned_SchoolData, "Data_Cleaning\\Data_Cleaned\\Cleaned_School_Data.csv",row.names = FALSE)

Post=read.csv("Data_Cleaning\\Data_Cleaned\\House_Price_2019-2022.csv") %>% 
  select(PostCode,County) %>% 
  mutate(S_Postcode=gsub(pattern,"",PostCode)) %>% 
  select(County,S_Postcode)

# School data cleaning seperatly for OXFORDSHIRE and YORKSHIRE

OXFORSSHIRESchoolData = Cleaned_SchoolData %>% 
  left_join(Post,by = "S_Postcode") %>% 
  select(Year, PostCode, S_Postcode, SchoolName, Attainment8Score,County) %>% 
  filter(County=="OXFORDSHIRE") %>% 
  na.omit() %>% 
  distinct() %>% 
  mutate(ID = row_number()) %>% 
  select(ID,Year, PostCode, S_Postcode, SchoolName, Attainment8Score)

write.csv(OXFORSSHIRESchoolData, "Data_Cleaning\\Data_Cleaned\\OXFORSSHIRESchoolData.CSV",row.names = FALSE) 

YORKSHIRESchoolData = Cleaned_SchoolData %>% 
  left_join(Post,by = "S_Postcode") %>% 
  select(Year, PostCode, S_Postcode, SchoolName, Attainment8Score,County) %>% 
  filter(County=="YORK" | County=="WEST YORKSHIRE" | County=="SOUTH YORKSHIRE" | County=="NORTH YORKSHIRE") %>% 
  na.omit() %>% 
  distinct() %>% 
  mutate(ID = row_number()) %>% 
  select(ID,Year, PostCode, S_Postcode, SchoolName, Attainment8Score)

View(YORKSHIRESchoolData)
write.csv(YORKSHIRESchoolData, "Data_Cleaning\\Data_Cleaned\\YORKSHIRESchoolData.CSV",row.names = FALSE)
