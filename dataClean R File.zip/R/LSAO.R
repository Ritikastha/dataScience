library(tidyverse)
library(dplyr)
library(data.table)

setwd("C:\\Users\\rg\\Desktop\\Data_Science_Assignment")
Cleaned= read.csv("Data_Cleaning\\Data_Cleaned\\Cleaned_Population.csv" )

LSOA_Data = fread("Datasets\\Postcode to LSOA.csv")
pattern = ' .*$'

LSOA_Data_Cleaned = LSOA_Data %>%
  select(lsoa11cd,pcds) %>% 
  mutate(S_Postcode=gsub(pattern,"",pcds)) %>% 
  right_join(Cleaned,by="S_Postcode")  %>% 
  group_by(lsoa11cd) %>% 
  select(lsoa11cd,S_Postcode,Town,District,County) 

view(LSOA_Data_Cleaned)
colnames(LSOA_Data_Cleaned)[1] <- "LSOA code"
write.csv(LSOA_Data_Cleaned,"Data_Cleaning\\Data_Cleaned\\Cleaned_LSOA_Data.csv",row.names = FALSE,col.names = FALSE)
