library(tidyverse)
library(dplyr)
library(stringi)
library(scales)
#set working directory
setwd("C:\\Users\\rg\\Desktop\\Data_Science_Assignment")

Broadband= read_csv("Datasets\\broadband speed\\201805_fixed_pc_performance_r03.csv", show_col_types = FALSE)
pattern = ' .*$'
Broadband_Data = Broadband %>%
  mutate(S_Postcode=gsub(pattern,"",postcode_space)) %>% 
  mutate(ID = row_number()) %>% 
  select(`ID`, `postcode area`, S_Postcode, `Average download speed (Mbit/s)`,
         `Average upload speed (Mbit/s)`, `Minimum download speed (Mbit/s)`,
         `Minimum upload speed (Mbit/s)`) %>% 
  na.omit() %>% 
  distinct() 
colnames(Broadband_Data) = c( "ID","postcode area", "S_Postcode", "Avgdownload",
                             "Average upload speed (Mbit/s)", "Mindownload",
                             "Minimum upload speed (Mbit/s)")
write.csv(Broadband_Data,"Data_Cleaning\\Data_Cleaned\\Broadband_Data_Cleaned.csv",row.names = FALSE)
