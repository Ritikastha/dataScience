library(tidyverse)
library(dplyr)
library(stringi)
library(scales)
setwd("C:\\Users\\rg\\Desktop\\Data_Science_Assignment")
uncleaned_Houseprice = read_csv("Data_Cleaning\\Data_Cleaned\\House_Price_2019-2022.csv")
Population = read_csv("Datasets\\Population2011_1656567141570.csv", show_col_types = FALSE)

view(uncleaned_Houseprice)

Filtered_Town = filter(uncleaned_Houseprice, County == 'OXFORDSHIRE' | County == 'YORK' | County == 'WEST YORKSHIRE' | County == 'NORTH YORKSHIRE' | County == 'SOUTH YORKSHIRE' )
pattern = ' .*$'

Population = Population %>%  
  mutate(S_Postcode=gsub(pattern,"",Postcode)) %>%
  group_by(S_Postcode) %>%
  summarise_at(vars(Population),list(Population2011 = sum)) %>%
  mutate(Population2012= (1.00695353132322269 * Population2011)) %>%
  mutate(Population2013= (1.00669740535540783 * Population2012)) %>%
  mutate(Population2014= (1.00736463978721671 * Population2013)) %>%
  mutate(Population2015= (1.00792367505802859 * Population2014)) %>%
  mutate(Population2015= (1.00792367505802859 * Population2014)) %>%
  mutate(Population2016= (1.00757874492811929 * Population2015)) %>%
  mutate(Population2017= (1.00679374473924223 * Population2016)) %>%
  mutate(Population2018= (1.00605929132212552 * Population2017)) %>%
  mutate(Population2019= (1.00561255390388033 * Population2018)) %>%
  mutate(Population2020= (1.00561255390388033 * Population2019)) %>%
  mutate(Population2021= (1.00561255390388033 * Population2020)) %>%
  mutate(Population2022= (1.00561255390388033 * Population2021)) %>%
  
  select(S_Postcode,Population2019,Population2020,Population2021,Population2022)
view(Population)

Filtered_Town = Filtered_Town %>% 
  mutate(S_Postcode=gsub(pattern,"",PostCode)) %>%
  mutate(Year = str_trim(substring(Year, 1,4))) %>% 
  left_join(Population,by="S_Postcode") %>% 
  select(PostCode, S_Postcode, Year, Town, District, County, Population2019,Population2020,Population2021,Population2022) %>% 
  group_by(S_Postcode) %>%
  arrange(County) %>% 
  as_tibble() %>% 
  na.omit() %>% 
  distinct()


# Replace "YORK" with "YORKSHIRE" in the COUNTY column
Filtered_Town$County[Filtered_Town$County == "YORK"] <- "YORKSHIRE"

View(Filtered_Town)

write.csv(Filtered_Town, "Data_Cleaning\\Data_Cleaned\\Cleaned_Population.csv",row.names = FALSE)
