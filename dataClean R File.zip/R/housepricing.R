install.packages("tidyverse")
library(tidyverse)
library(dplyr)
library(stringi)
library(stringr)
library(scales)
library(lubridate)


setwd("C:\\Users\\rg\\Desktop\\Data_Science_Assignment")


nineteen=read_csv("Datasets\\housepricing2019.csv",show_col_types = FALSE)
twenty=read_csv("Datasets\\housepricing2020.csv",show_col_types = FALSE)
twentyone=read_csv("Datasets\\housepricing2021.csv",show_col_types = FALSE)
twentytwo=read_csv("Datasets\\housepricing2022.csv",show_col_types = FALSE)


colnames(nineteen) = c("ID" , "Price", "Year", "PostCode" , "PAON", "SAON", "FL", "House Num", "Flat", "Street Name",
                     "Locality", "Town" , "District", "County", "Type1", "Type2" )
colnames(twenty) = c("ID" , "Price", "Year", "PostCode" , "PAON", "SAON", "FL", "House Num", "Flat", "Street Name",
                     "Locality", "Town" , "District", "County", "Type1", "Type2")
colnames(twentyone) = c("ID" , "Price", "Year", "PostCode" , "PAON", "SAON", "FL", "House Num", "Flat", "Street Name",
                     "Locality", "Town" , "District", "County" , "Type1", "Type2")
colnames(twentytwo) = c("ID" , "Price", "Year", "PostCode" , "PAON", "SAON", "FL", "House Num", "Flat", "Street Name",
                     "Locality", "Town" , "District", "County" , "Type1", "Type2")

# HousePrice_19_20 = rbind(nineteen,twenty)
# HousePrice_21_22 = rbind(twentyone,twentytwo)
# 
# HousePrice_19_20$Year <- mdy((gsub("\\ .*", "", HousePrice_19_20$Year)))
# HousePrice_21_22$Year <- ymd((gsub("\\ .*", "", HousePrice_21_22$Year)))

HousePrice_19_20 = rbind(nineteen,twenty) %>% 
  mutate(Year = mdy((gsub("\\ .*", "", Year))))

HousePrice_21_22 = rbind(twentyone,twentytwo) %>% 
  mutate(Year = ymd((gsub("\\ .*", "", Year))))

# HousePrice = rbind(HousePrice_19_20, HousePrice_21_22)

# HousePrice = rbind(nineteen,twenty,twentyone,twentytwo) %>% 
#HousePrice = rbind(nineteen,twenty,twentyone,twentytwo) %>% 
#   na.omit() %>% 
#   distinct() %>% 
#   as_tibble()
# View(HousePrice)
  
  
HousePrice = rbind(HousePrice_19_20, HousePrice_21_22) %>%
  na.omit() %>%
  distinct() %>%
  as_tibble()
View(HousePrice)

write.csv(HousePrice, "Data_Cleaning\\Data_Cleaned\\House_Price_2019-2022.csv")


FilteredHousePrice = filter(HousePrice, County == 'OXFORDSHIRE' | County == 'YORK' | County == 'WEST YORKSHIRE' | County == 'NORTH YORKSHIRE' | County == 'SOUTH YORKSHIRE' )

# Replace "YORK" with "YORKSHIRE" in the COUNTY column
FilteredHousePrice$County[FilteredHousePrice$County == "YORK"] <- "YORKSHIRE"
view(FilteredHousePrice)


# FilteredHousePrice$Year <- format(FilteredHousePrice$Year, "%Y")

pattern = ' .*$'
# rm(FilteredHousePrice)
FilteredHousePrice = FilteredHousePrice %>% 
  mutate(S_Postcode=gsub(pattern,"",PostCode)) %>%
  mutate(Year = format(Year, "%Y")) %>%
  select(PostCode,S_Postcode,Year,PAON,Price) %>% 
  na.omit() %>% 
  distinct() %>% 
  as_tibble()
View(FilteredHousePrice)


# export filteredhouseprices data set to  csv
write.csv(FilteredHousePrice, "Data_Cleaning\\Data_Cleaned\\Cleaned_House_Price_2019-2022.csv",row.names = FALSE)
